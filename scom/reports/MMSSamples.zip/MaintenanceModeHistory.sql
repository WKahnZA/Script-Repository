-- Author: Kevin Holman
-- From: http://blogs.technet.com/kevinholman/archive/2009/06/11/outages-and-maintenance-report.aspx
-- Updated by Chris Harris


declare @startdate datetime 
declare @enddate datetime 
SET @startdate = '2010-03-01 00:00:00.000' 
SET @enddate = getutcdate() 

declare @computergroups varchar(50) 
set @computergroups = 'Agent Managed Computer Group' 

-- Create a table variable to hold the count of history IDs per MM ID 
-- so the total duration can be divided by the number of history IDs
-- This prevents duration of outages from being counted twice 
Declare @tv_mmHistoryCount Table(MaintenanceModeRowID int,HistoryCount int)
Insert into @tv_mmHistoryCount (MaintenanceModeRowID,HistoryCount)

	select vmm.MaintenanceModeRowId,COUNT (vmmh.MaintenanceModeHistoryRowId) as Count
	from vMaintenanceMode vmm 
	join vManagedEntity vme on vmm.managedentityrowid = vme.managedentityrowid 
	join vMaintenanceModeHistory vmmh on vmm.maintenancemoderowid = vmmh.maintenancemoderowid 
	where vme.FullName LIKE '%HealthServiceWatcher%' 
	and (DATEADD(hh,DATEDIFF(hh,getutcdate(),getdate()),vmm.StartDateTime)) between @startdate and @enddate 
	and vme.displayname IN ( 
	SELECT vManagedEntity.DisplayName 
	FROM  vManagedEntity 
	INNER JOIN vRelationship ON vManagedEntity.ManagedEntityRowId = vRelationship.TargetManagedEntityRowId 
	INNER JOIN vManagedEntity AS ManagedEntity_1 ON vRelationship.SourceManagedEntityRowId = ManagedEntity_1.ManagedEntityRowId 
	WHERE (ManagedEntity_1.DisplayName = @computergroups) 
	) 
	Group By vmm.MaintenanceModeRowId

select 
vme.displayname as SystemName,
(DATEADD(hh,DATEDIFF(hh,getutcdate(),getdate()),vmm.StartDateTime)) as DownDateTime, 
--(DATEADD(hh,DATEDIFF(hh,getutcdate(),getdate()),vmm.EndDateTime)) as RestoredDateTime,
Convert(decimal(10,2),(
	Convert(decimal(10,5),(
		(DATEADD(hh,DATEDIFF(hh,getutcdate(),getdate()),vmm.EndDateTime)) - (DATEADD(hh,DATEDIFF(hh,getutcdate(),getdate()),vmm.StartDateTime)) )				
		)
	)/tvmmhc.HistoryCount*24*60) as MaintenanceDurationMin,
'OutageType' = 
CASE 
  vmm.PlannedMaintenanceInd 
  WHEN '1' THEN 'Scheduled' 
  WHEN '0' THEN 'Unscheduled' 
END, 
'RootCause' = 
CASE 
  vmmh.ReasonCode 
  WHEN '0' THEN 'Other (Planned)' 
  WHEN '1' THEN 'Other (Unplanned)' 
  WHEN '2' THEN 'Hardware: Maintenance (Planned)' 
  WHEN '3' THEN 'Hardware: Maintenance (Unplanned)' 
  WHEN '4' THEN 'Hardware: Installation (Planned)' 
  WHEN '5' THEN 'Hardware: Installation (Unplanned)' 
  WHEN '6' THEN 'Operating System: Reconfiguration (Planned)' 
  WHEN '7' THEN 'Operating System: Reconfiguration (Unplanned)' 
  WHEN '8' THEN 'Application: Maintenance (Planned)' 
  WHEN '9' THEN 'Application: Maintenance (Unplanned)' 
  WHEN '10' THEN 'Application: Installation (Planned)' 
  WHEN '11' THEN 'Application: Unresponsive' 
  WHEN '12' THEN 'Application:  Unstable' 
  WHEN '13' THEN 'Security Issue' 
  WHEN '14' THEN 'Loss of network connectivity (Unplanned)' 
END, 
vmmh.Comment as Reason, 
vmmh.userid as UserID 
from vMaintenanceMode vmm 
join @tv_mmHistoryCount tvmmhc on vmm.MaintenanceModeRowId = tvmmhc.MaintenanceModeRowID
join vManagedEntity vme on vmm.managedentityrowid = vme.managedentityrowid 
join vMaintenanceModeHistory vmmh on vmm.maintenancemoderowid = vmmh.maintenancemoderowid 
where vme.FullName LIKE '%HealthServiceWatcher%' 
and (DATEADD(hh,DATEDIFF(hh,getutcdate(),getdate()),vmm.StartDateTime)) between @startdate and @enddate 
and vme.displayname IN ( 
SELECT vManagedEntity.DisplayName 
FROM  vManagedEntity 
INNER JOIN vRelationship ON vManagedEntity.ManagedEntityRowId = vRelationship.TargetManagedEntityRowId 
INNER JOIN vManagedEntity AS ManagedEntity_1 ON vRelationship.SourceManagedEntityRowId = ManagedEntity_1.ManagedEntityRowId 
WHERE (ManagedEntity_1.DisplayName = @computergroups) 
) 
ORDER BY DownDateTime desc
